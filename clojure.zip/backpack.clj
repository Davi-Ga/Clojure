(def itens [{:valor 6 :peso 6}
            {:valor 9 :peso 6}
            {:valor 10 :peso 5}
            {:valor 5 :peso 6}
            {:valor 5 :peso 10}])

(defn mochila [itens peso-maximo]
    (let [[itens-na-mochila, valor-total]
          (reduce
           (fn [[itens-na-mochila valor-total] item]
             (let [novo-peso (+ (reduce + (map :peso itens-na-mochila)) (:peso item))]
               (if (<= novo-peso peso-maximo)
                 [(conj itens-na-mochila item) (+ valor-total (:valor item))]
                 [itens-na-mochila valor-total])))
           [[] 0]
           (sort-by (fn [item] (/ (:peso item) (:valor item))) itens))]
      (do (println itens-na-mochila)
          valor-total)))

(mochila itens 20) 